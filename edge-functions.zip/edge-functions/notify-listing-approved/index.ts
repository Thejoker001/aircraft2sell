// ============================================================
// supabase/functions/notify-listing-approved/index.ts
// Edge Function — Notifie le vendeur quand son annonce est approuvée
// Appelée automatiquement depuis admin-approve-listing ou via trigger
// ============================================================

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': 'https://aircraft2sell.eu',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const { listing_id } = await req.json()
    if (!listing_id) return new Response(JSON.stringify({ error: 'Missing listing_id' }), { status: 400, headers: corsHeaders })

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { data: listing, error } = await supabase
      .from('listings')
      .select('*')
      .eq('id', listing_id)
      .single()

    if (error || !listing) throw new Error('Listing not found')

    const BREVO_KEY = Deno.env.get('BREVO_API_KEY')
    if (!BREVO_KEY) return new Response(JSON.stringify({ ok: true, skipped: 'no brevo key' }), { status: 200, headers: corsHeaders })

    await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: { 'api-key': BREVO_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sender: { name: 'Aircraft2Sell', email: 'noreply@aircraft2sell.eu' },
        to: [{ email: listing.seller_email, name: listing.seller_name ?? listing.seller_email }],
        subject: '✅ Votre annonce est en ligne — Aircraft2Sell',
        htmlContent: `
          <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
            <div style="background:#05080f;padding:24px;text-align:center">
              <h1 style="font-family:Georgia,serif;color:#e8a020;letter-spacing:4px;margin:0">AIRCRAFT2SELL</h1>
            </div>
            <div style="padding:32px;background:#ffffff">
              <div style="background:#f0fdf4;border:1px solid #86efac;padding:16px;text-align:center;margin-bottom:24px">
                <div style="font-size:32px">✅</div>
                <h2 style="color:#16a34a;margin:8px 0">Annonce publiée !</h2>
              </div>
              <p>Bonjour ${listing.seller_name ?? ''},</p>
              <p style="color:#555;line-height:1.7">Votre annonce <strong>${listing.make} ${listing.model} ${listing.year ? '(' + listing.year + ')' : ''}</strong> vient d'être validée et est maintenant visible par tous les acheteurs européens.</p>
              <div style="background:#f9f9f9;border:1px solid #eee;padding:20px;margin:24px 0">
                <table style="width:100%;font-size:14px">
                  <tr><td style="color:#888;padding:4px 0">Aéronef</td><td style="font-weight:600">${listing.make} ${listing.model}</td></tr>
                  <tr><td style="color:#888;padding:4px 0">Prix</td><td style="font-weight:600;color:#e8a020">${listing.price ? Number(listing.price).toLocaleString('fr-FR') + ' ' + (listing.currency ?? 'EUR') : '—'}</td></tr>
                  <tr><td style="color:#888;padding:4px 0">Localisation</td><td>${listing.airport ?? '—'}</td></tr>
                </table>
              </div>
              <div style="text-align:center;margin:32px 0">
                <a href="https://aircraft2sell.eu/dashboard.html" style="background:#e8a020;color:#05080f;text-decoration:none;padding:14px 32px;font-weight:700;font-size:16px;display:inline-block">Voir mon tableau de bord →</a>
              </div>
              <p style="color:#999;font-size:13px">Vous pouvez modifier ou supprimer votre annonce à tout moment depuis votre espace personnel.</p>
            </div>
            <div style="background:#f5f5f5;padding:16px;text-align:center;font-size:12px;color:#999">
              © ${new Date().getFullYear()} Aircraft2Sell · <a href="https://aircraft2sell.eu/legal.html" style="color:#e8a020">Mentions légales</a>
            </div>
          </div>
        `,
      }),
    })

    return new Response(JSON.stringify({ ok: true }), { status: 200, headers: corsHeaders })
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders })
  }
})
