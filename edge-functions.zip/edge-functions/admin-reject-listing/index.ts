// ============================================================
// supabase/functions/admin-reject-listing/index.ts
// Edge Function — Rejeter une annonce avec motif
// ============================================================

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': 'https://aircraft2sell.eu',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: corsHeaders })

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser()
    if (userError || !user) return new Response(JSON.stringify({ error: 'Invalid token' }), { status: 401, headers: corsHeaders })

    const ADMIN_EMAILS = (Deno.env.get('ADMIN_EMAILS') ?? '').split(',').map(e => e.trim())
    if (!ADMIN_EMAILS.includes(user.email ?? '')) return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: corsHeaders })

    const { id, reason } = await req.json()
    if (!id) return new Response(JSON.stringify({ error: 'Missing id' }), { status: 400, headers: corsHeaders })

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { data, error } = await supabaseAdmin
      .from('listings')
      .update({ status: 'rejected', rejection_reason: reason ?? null })
      .eq('id', id)
      .select()
      .single()

    if (error) throw error

    // Notifier le vendeur par email via Brevo
    const sellerEmail = data.seller_email
    if (sellerEmail && Deno.env.get('BREVO_API_KEY')) {
      await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: {
          'api-key': Deno.env.get('BREVO_API_KEY') ?? '',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sender: { name: 'Aircraft2Sell', email: 'noreply@aircraft2sell.eu' },
          to: [{ email: sellerEmail, name: data.seller_name ?? sellerEmail }],
          subject: 'Votre annonce Aircraft2Sell a été refusée',
          htmlContent: `
            <p>Bonjour ${data.seller_name ?? ''},</p>
            <p>Votre annonce <strong>${data.make} ${data.model}</strong> n'a pas pu être publiée.</p>
            ${reason ? `<p><strong>Motif :</strong> ${reason}</p>` : ''}
            <p>Vous pouvez la corriger et la resoumettre depuis votre <a href="https://aircraft2sell.eu/dashboard.html">tableau de bord</a>.</p>
            <p>L'équipe Aircraft2Sell</p>
          `,
        }),
      })
    }

    return new Response(JSON.stringify({ ok: true }), {
      status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
})
