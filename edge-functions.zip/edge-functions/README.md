# Edge Functions — Aircraft2Sell
## Déploiement (5 minutes)

### Prérequis
```bash
npm install -g supabase
supabase login
supabase link --project-ref hlivysnlzlqdjcigqgvk
```

### Variables d'environnement à configurer dans Supabase Dashboard
→ Project Settings > Edge Functions > Secrets

| Variable | Valeur |
|----------|--------|
| `BREVO_API_KEY` | Ta clé API Brevo (Settings > API Keys) |
| `ADMIN_EMAIL` | contact.aircraft2sell@gmail.com |
| `ADMIN_EMAILS` | contact.aircraft2sell@gmail.com |

### Déployer les 4 fonctions
```bash
supabase functions deploy admin-approve-listing
supabase functions deploy admin-reject-listing
supabase functions deploy send-contact-email
supabase functions deploy notify-listing-approved
```

### Mettre à jour admin-a2s00760.html
Remplacer dans le JS les appels `sb('PATCH', 'listings', ...)` par :

```javascript
// Ancienne version (service_role exposée) :
await sb('PATCH', 'listings', 'id=eq.'+id, {status:'live'})

// Nouvelle version (Edge Function) :
async function approveViaEdge(id) {
  const token = sessionStorage.getItem('a2s_admin_session')
  const res = await fetch('https://hlivysnlzlqdjcigqgvk.supabase.co/functions/v1/admin-approve-listing', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ id })
  })
  return res.json()
}
```

### Mettre à jour contact.html
Remplacer le `submitForm()` par :

```javascript
async function submitForm() {
  // ... validation ...
  const res = await fetch('https://hlivysnlzlqdjcigqgvk.supabase.co/functions/v1/send-contact-email', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ firstName, lastName, email, subject, message })
  })
  const data = await res.json()
  if (data.ok) {
    // Afficher succès
  }
}
```
